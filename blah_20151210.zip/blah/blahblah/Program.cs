﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using log4net;
using blahblah.Utilities;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace blahblah
{
    public class Program
    {
        //configuration variables
        static Boolean loadTree = false, loadRule = true;
        static String logFolder = @"C:\FFXLog\SchemaGenerator\", logPrefix;
        static String[] files = Directory.GetFiles(@"\\10.101.17.16\c$\Users\fizerc\Desktop\oldstuff\ConvertedRegs\Titles\Title_1\1-1h\convertedfiles\eReg\1", "*.dita", SearchOption.AllDirectories);
        //static String[] files = Directory.GetFiles(@"\\10.101.17.16\c$\Users\fizerc\Desktop\oldstuff\ConvertedRegs\Titles", "*.dita", SearchOption.AllDirectories);

        //code used variables
        static NodeClass resultTree;
        static List<NodeClass> resultRule;
        static ILog log;

        static void Main(string[] args)
        {
            logPrefix = String.Format("{0}T{1}-", DateTime.Now.ToString("yyyyMMdd"), DateTime.Now.ToString("hhmmss"));
            GlobalContext.Properties["LogName"] = logPrefix + "Log.txt";
            log = LogUtility.GetLogger();

            Console.WriteLine("Extracting files from the directory...");
            if (files.Length == 0)
            {
                Console.WriteLine("Cannot find .dita files in the directory.");
                Environment.Exit(0);
            }
            Console.WriteLine(String.Format("Found {0} files. Start processing...\n", files.Length));

            int finished = 0;
            int failed = 0;
            resultTree = new NodeClass();
            resultRule = new List<NodeClass>();

            foreach (String file in files)
            {
                if (finished % 100 == 0)
                    Console.Title = String.Format("Processed {0:F2}% of files...", ((decimal)finished * 100 / (decimal)files.Length));

                using (Stream xmlStream = File.OpenRead(file))
                {
                    if (xmlStream.Length == 0)
                    {
                        Console.WriteLine("***ERROR: Cannot read file: " + Path.GetFileName(file));
                        failed++;
                        continue;
                    }

                    XmlDocument xml = new XmlDocument();
                    xml.Load(xmlStream);

                    LoadEls(xml.DocumentElement);
                }

                finished++;
            }
            Console.WriteLine(String.Format("Process complete. {0} of files failed.\n", failed));

            Console.WriteLine("Printing Tree/Rule to files at:\n" + logFolder);
            PrintResults();
            Console.WriteLine("Printing complete.");
        }

        static void LoadEls(XmlElement root)
        {
            Task treeTask = null, ruleTask = null;

            if (loadTree)
            {
                resultTree = new NodeClass(root.Name);
                treeTask = new Task(() => LoadChildTree(root, resultTree));
            }

            if (loadRule)
            {
                resultRule.Add(new NodeClass(root.Name));
                ruleTask = new Task(() => LoadChildRule(root, resultRule[0]));
            }

            if (!Object.ReferenceEquals(treeTask, null))
                treeTask.Start();
            if (!Object.ReferenceEquals(ruleTask, null))
                ruleTask.Start();

            if (!Object.ReferenceEquals(treeTask, null))
                treeTask.Wait();
            if (!Object.ReferenceEquals(ruleTask, null))
                ruleTask.Wait();
        }

        static void LoadChildTree(XmlNode parentEl, NodeClass parentTree)
        {
            foreach (XmlNode currentEl in parentEl)
            {
                //jump <table>
                if (currentEl.Name.Equals("table"))
                    continue;

                NodeClass currentNodeTree = parentTree.GetChild(currentEl.Name);
                if (Object.ReferenceEquals(currentNodeTree, null))
                    //new tree
                    currentNodeTree = new NodeClass(currentEl.Name);
                parentTree.childNodes.Add(currentNodeTree);

                //check child
                if (currentEl.HasChildNodes)
                    foreach (XmlNode childEl in currentEl)
                        LoadChildTree(childEl, currentNodeTree);
            }
        }

        static void LoadChildRule(XmlNode parentEl, NodeClass parentRule)
        {
            foreach (XmlNode currentEl in parentEl)
            {
                //jump <table>
                if (currentEl.Name.Equals("table"))
                    continue;

                NodeClass currentNodeRule = new NodeClass(parentEl.Name);
                Boolean newRule = true;
                foreach (NodeClass result in resultRule)
                    if (result.name.Equals(parentEl.Name))
                    {
                        //new rule
                        currentNodeRule = result;
                        newRule = false;
                        break;
                    }
                if (newRule)
                    resultRule.Add(currentNodeRule);
                if (!parentRule.HasChild(parentEl.Name))
                    //new child
                    parentRule.childNodes.Add(currentNodeRule);

                //check child
                if (currentEl.HasChildNodes)
                    foreach (XmlNode childEl in currentEl)
                        LoadChildTree(childEl, currentNodeRule);
            }
        }

        static void PrintResults()
        {
            Task treePrint = null, rulePrint = null;

            if (loadTree)
            {
                treePrint = new Task(() => PrintTree(resultTree));
            }

            if (loadRule)
            {
                rulePrint = new Task(() => PrintRule());
            }

            if (!Object.ReferenceEquals(treePrint, null))
                treePrint.Start();
            if (!Object.ReferenceEquals(rulePrint, null))
                rulePrint.Start();

            if (!Object.ReferenceEquals(treePrint, null))
                treePrint.Wait();
            if (!Object.ReferenceEquals(rulePrint, null))
                rulePrint.Wait();
        }

        static void PrintTree(NodeClass currentNode, int depth = 0)
        {
            String logPath = Path.Combine(logFolder, logPrefix + "Tree.txt");
            TextWriter writer = new StreamWriter(logPath, true);

            String logLine = "";
            for (int i = 0; i < depth; i++)
                logLine += "-";
            logLine += currentNode.name;
            LogUtility.LogIt(logLine, writer);

            if (currentNode.childNodes.Count > 0)
                foreach (NodeClass childNode in currentNode.childNodes)
                    PrintTree(childNode, depth + 1);
        }

        static void PrintRule()
        {
            String logPath = Path.Combine(logFolder, logPrefix + "Tree.txt");
            TextWriter writer = new StreamWriter(logPath, true);

            //namespaces
            LogUtility.LogIt("<?xml version=\"1.0\" encoding=\"utf-8\"?>", writer);
            LogUtility.LogIt("<xs:schema elementFormDefault=\"qualified\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:ditaarch=\"http://dita.oasis-open.org/architecture/2005/\">", writer);
            LogUtility.LogIt("", writer);

            //root
            LogUtility.LogIt(String.Format("<xs:element name=\"{0}\" type=\"{0}Type\"/>", resultRule[0].name), writer);

            foreach (NodeClass node in resultRule)
            {
                if (node.childNodes.Count == 0)
                    continue;
                if (node.name.Equals("#text"))
                    continue;

                LogUtility.LogIt(String.Format("<xs:complexType name=\"{0}\">", node.name + "Type"), writer);
                LogUtility.LogIt("<xs:sequence>", writer);
                LogUtility.LogIt("<xs:choice maxOccurs=\"unbounded\">", writer);
                LogUtility.LogIt("", writer);

                foreach (NodeClass childNode in node.childNodes)
                {
                    String logLine = "";
                    if (childNode.childNodes.Count == 0 || childNode.childNodes[0].name.Equals("#text"))
                        logLine = String.Format("<xs:element name=\"{0}\" type=\"{1}\"/>", childNode.name, "xs:string");
                    else
                        logLine = String.Format("<xs:element name=\"{0}\" type=\"{1}\"/>", childNode.name, childNode.name + "Type");
                    LogUtility.LogIt(logLine, writer);
                }

                LogUtility.LogIt("</xs:choice>", writer);
                LogUtility.LogIt("</xs:sequence>", writer);
                LogUtility.LogIt("</xs:complexType>", writer);
            }

            LogUtility.LogIt("</xs:schema>", writer);
            LogUtility.LogIt("", writer);
        }
    }
}
