﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blah2
{
    class ShcemaElement
    {
        public String ElementName { get; set; }

        public List<String> Attributes { get; set; }

        private List<Sche>
    }
}
