﻿using FileNet.Api.Core;
using FileNet.Api.Meta;
using FileNet.Api.Property;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JanetExtractFN
{
    class Program
    {
        public static String filePath;
        public static List<String> exportedRootSymbolicNames, nonexportedRootSymbolicNames, exportedSystemPropertySymbolicNames;

        static void Main(string[] args)
        {
            if (String.IsNullOrEmpty(ConfigurationManager.AppSettings["targetGuid1"]))
            {
                Console.WriteLine("Cannot find target guid(s). Exiting...");
                Environment.Exit(0);
            }

            //connect to FileNet
            Console.Title = "Connecting to FileNet...";
            CEConnection conn = CEConnection.getCEConnectionInstance();
            Console.Title = "FileNet Connected";

            //get prepared
            filePath = ConfigurationManager.AppSettings["outputStructureFilePath"];
            File.Delete(filePath);
            exportedRootSymbolicNames = ConfigurationManager.AppSettings["exportedRootSymbolicNames"].Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList<String>();
            nonexportedRootSymbolicNames = ConfigurationManager.AppSettings["nonexportedRootSymbolicNames"].Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList<String>();
            exportedSystemPropertySymbolicNames = ConfigurationManager.AppSettings["exportedSystemPropertySymbolicNames"].Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList<String>();

            int i = 1;
            while (true)
            {
                String guid = ConfigurationManager.AppSettings["targetGuid" + i];

                if (String.IsNullOrEmpty(guid))
                    break;

                IClassDescription targetClass = Factory.ClassDescription.FetchInstance(conn.ObjectStore, guid, new PropertyFilter());
                Console.WriteLine("Start dumping class: " + targetClass.SymbolicName);
                Console.Title = "Dumping...";
                DumpFromFileNet(targetClass);
                Console.Title = "Dumping Finished";

                i++;
            }
        }

        static void DumpFromFileNet(IClassDescription targetClass)
        {
            //class definition
            String line = targetClass.SymbolicName + " ";
            //parent class

            if (!IsRoot(targetClass))
            {
                line += ": " + targetClass.SuperclassDescription.SymbolicName + " ";
                if (exportedRootSymbolicNames.Contains(targetClass.SuperclassDescription.SymbolicName))
                {
                    File.AppendAllText(filePath, targetClass.SuperclassDescription.SymbolicName + " {" + Environment.NewLine);
                    DumpProperties(targetClass.SuperclassDescription);
                    File.AppendAllText(filePath, "}" + Environment.NewLine + Environment.NewLine);
                }
            }
            line += "{" + Environment.NewLine;
            File.AppendAllText(filePath, line);

            //property definition
            DumpProperties(targetClass);

            //close class
            File.AppendAllText(filePath, "}" + Environment.NewLine + Environment.NewLine);

            //check child class
            foreach (IClassDescription childClass in targetClass.ImmediateSubclassDescriptions)
                DumpFromFileNet(childClass);
        }

        static void DumpProperties(IClassDescription targetClass)
        {
            foreach (IPropertyDescription property in targetClass.PropertyDescriptions)
            {
                //system property
                if ((property.IsSystemOwned == true) && !exportedSystemPropertySymbolicNames.Contains(property.SymbolicName))
                    continue;

                //inherited property
                Boolean inherited = false;
                if (!IsRoot(targetClass))
                    foreach (IPropertyDescription superclassProperty in targetClass.SuperclassDescription.PropertyDescriptions)
                        if (superclassProperty.SymbolicName.Equals(property.SymbolicName))
                        {
                            inherited = true;
                            break;
                        }

                //new property
                if (!inherited)
                    File.AppendAllText(filePath, "[" + property.SymbolicName + "](" + property.DataType.ToString() + ")" + Environment.NewLine);
            }
        }

        static Boolean IsRoot(IClassDescription targetClass)
        {
            return Object.ReferenceEquals(null, targetClass.SuperclassDescription) || nonexportedRootSymbolicNames.Contains(targetClass.SuperclassDescription.SymbolicName);
        }
    }
}
